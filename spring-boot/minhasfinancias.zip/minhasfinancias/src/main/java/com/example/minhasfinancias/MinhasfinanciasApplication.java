package com.example.minhasfinancias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinhasfinanciasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinhasfinanciasApplication.class, args);
	}

}
